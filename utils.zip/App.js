// App.js
import React from "react";
import { NavigationContainer, DefaultTheme } from "@react-navigation/native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";

import HomeScreen from "./screens/HomeScreen";
import TransferScreen from "./screens/TransferScreen";
import WalletScreen from "./screens/WalletScreen";
import ProfileScreen from "./screens/ProfileScreen";
import AddExpenseScreen from "./screens/AddExpenseScreen";
import BottomBar from "./components/BottomBar";
import { COLORS } from "./utils/theme";

const Tab = createBottomTabNavigator();

const theme = {
  ...DefaultTheme,
  colors: { ...DefaultTheme.colors, background: COLORS.bg },
};

export default function App() {
  return (
    <NavigationContainer theme={theme}>
      <Tab.Navigator
        initialRouteName="Home"
        screenOptions={{ headerShown: false }}
        tabBar={(props) => <BottomBar {...props} />}
      >
        <Tab.Screen name="Home" component={HomeScreen} />
        <Tab.Screen name="Transfer" component={TransferScreen} />
        {/* Hidden from bar; opened via FAB */}
        <Tab.Screen
          name="AddExpense"
          component={AddExpenseScreen}
          options={{ tabBarButton: () => null }}
        />
        <Tab.Screen name="Wallet" component={WalletScreen} />
        <Tab.Screen name="Profile" component={ProfileScreen} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}
