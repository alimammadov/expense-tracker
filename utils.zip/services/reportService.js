// services/reportService.js
// JS only. Firestore v9 (modular).
import {
  collection,
  doc,
  getDoc,
  getDocs,
  onSnapshot,
  orderBy,
  query,
  where,
} from "firebase/firestore";
import { db } from "../firebase"; // ensure firebase.js exports `db`

const COL = "lungo_dailyRaport";
const colRef = collection(db, COL);

/** Utility: format Date -> 'YYYY-MM-DD' */
export const ymd = (d) => {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
};

/** Utility: add days (can be negative) and return a new Date */
export const addDays = (date, delta) => {
  const d = new Date(date);
  d.setDate(d.getDate() + delta);
  return d;
};

/** Map Firestore document -> shape expected by ReportScreen */
export const mapDocToReport = (docSnap) => {
  if (!docSnap?.exists()) return null;
  const d = docSnap.data() || {};
  const revenue = d.revenue || {};
  const byAmount = revenue.byChannel || {};
  const byOrders = revenue.ordersByChannel || {};

  return {
    id: docSnap.id,                     // 'YYYY-MM-DD'
    date: d.date || docSnap.id,         // keep your 'date' string
    totalRevenue: Number(revenue.total || 0),

    // ✅ Orders (total + per-channel)
    orders: Number(revenue.ordersTotal || 0),
    ordersByChannel: {
      inShop: Number(byOrders.inShop || 0),
      pyszne: Number(byOrders.pyszne || 0),
      wolt: Number(byOrders.wolt || 0),
      uber: Number(byOrders.uber || 0),
      glovo: Number(byOrders.glovo || 0),
      lungo: Number(byOrders.lungo || 0),
    },

    // Amounts by channel
    channels: {
      inShop: Number(byAmount.inShop || 0),
      pyszne: Number(byAmount.pyszne || 0),
      wolt: Number(byAmount.wolt || 0),
      uber: Number(byAmount.uber || 0),
      glovo: Number(byAmount.glovo || 0),
      lungo: Number(byAmount.lungo || 0),
    },

    cashInRegister: Number(d.cash?.today || 0),
    _raw: d, // optional: keep raw for future needs
  };
};

/** Get a single day by its ID (YYYY-MM-DD) */
export const getReportByDate = async (dateId) => {
  const snap = await getDoc(doc(db, COL, dateId));
  return mapDocToReport(snap);
};

/** Get reports in an inclusive range [startYmd, endYmd], sorted asc by date */
export const getReportsRange = async (startYmd, endYmd) => {
  // 'date' is stored as a string -> safe for range query
  const q = query(
    colRef,
    where("date", ">=", startYmd),
    where("date", "<=", endYmd),
    orderBy("date", "asc")
  );

  const snap = await getDocs(q);
  return snap.docs.map(mapDocToReport).filter(Boolean);
};

/** Get last N days up to 'today' (inclusive), sorted asc */
export const getLastNDays = async (n = 7, today = new Date()) => {
  const end = ymd(today);
  const start = ymd(addDays(today, -(n - 1)));
  return getReportsRange(start, end);
};

/** Subscribe to a single date doc; returns unsubscribe() */
export const subscribeReportByDate = (dateId, callback) => {
  const ref = doc(db, COL, dateId);
  return onSnapshot(
    ref,
    (snap) => callback(mapDocToReport(snap)),
    (err) => {
      console.error("subscribeReportByDate error:", err);
      callback(null);
    }
  );
};

/** Aggregate a list of report docs into totals (for charts/KPIs) */
export const summarizeReports = (reports) => {
  const sum = {
    totalRevenue: 0,
    orders: 0,
    channels: { inShop: 0, pyszne: 0, wolt: 0, uber: 0, glovo: 0, lungo: 0 },
    ordersByChannel: { inShop: 0, pyszne: 0, wolt: 0, uber: 0, glovo: 0, lungo: 0 },
    cashInRegister: 0,
    days: reports.length,
  };

  for (const r of reports) {
    sum.totalRevenue += r.totalRevenue || 0;
    sum.orders += r.orders || 0;

    sum.channels.inShop += r.channels.inShop || 0;
    sum.channels.pyszne += r.channels.pyszne || 0;
    sum.channels.wolt += r.channels.wolt || 0;
    sum.channels.uber += r.channels.uber || 0;
    sum.channels.glovo += r.channels.glovo || 0;
    sum.channels.lungo += r.channels.lungo || 0;

    if (r.ordersByChannel) {
      sum.ordersByChannel.inShop += r.ordersByChannel.inShop || 0;
      sum.ordersByChannel.pyszne += r.ordersByChannel.pyszne || 0;
      sum.ordersByChannel.wolt += r.ordersByChannel.wolt || 0;
      sum.ordersByChannel.uber += r.ordersByChannel.uber || 0;
      sum.ordersByChannel.glovo += r.ordersByChannel.glovo || 0;
      sum.ordersByChannel.lungo += r.ordersByChannel.lungo || 0;
    }

    sum.cashInRegister += r.cashInRegister || 0;
  }
  return sum;
};
