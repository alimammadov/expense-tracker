// screens/AddExpenseScreen.js
import React, { useMemo, useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Alert,
} from "react-native";
import DateTimePicker from "@react-native-community/datetimepicker";

const CATEGORIES = [
  "Ingredients",
  "Packaging",
  "Utilities",
  "Marketing",
  "Salary",
  "Delivery",
  "Other",
];

const SUPPLIERS = [
  "Chef Culinar",
  "Makro",
  "Biedronka",
  "Netto",
  "Żabka",
  "Obi",
  "Castroma",
  "Nihat",
  "Javid",
  "Miri",
  "Ali",
  "Other",
];

export default function AddExpenseScreen({ navigation }) {
  // date
  const [date, setDate] = useState(new Date());
  const [showDatePicker, setShowDatePicker] = useState(false);

  // core fields
  const [category, setCategory] = useState("");
  const [amount, setAmount] = useState("");   // per-unit/base amount
  const [quantity, setQuantity] = useState("1");
  const [description, setDescription] = useState("");

  // supplier
  const [supplier, setSupplier] = useState("");
  const [newSupplier, setNewSupplier] = useState("");

  const qtyNum = useMemo(() => {
    const n = parseFloat((quantity || "").replace(",", "."));
    return Number.isFinite(n) && n > 0 ? n : 0;
  }, [quantity]);

  const amountNum = useMemo(() => {
    const n = parseFloat((amount || "").replace(",", "."));
    return Number.isFinite(n) && n >= 0 ? n : 0;
  }, [amount]);

  const total = useMemo(() => +(amountNum * qtyNum).toFixed(2), [amountNum, qtyNum]);

  const supplierFinal =
    supplier === "Other" ? newSupplier.trim() : supplier;

  const canSave =
    date &&
    category &&
    amountNum > 0 &&
    qtyNum > 0 &&
    supplierFinal.length > 0;

  const onSave = () => {
    if (!canSave) {
      Alert.alert("Missing info", "Select date, category, supplier, and enter valid amount/quantity.");
      return;
    }

    const payload = {
      date: formatDate(date),        // YYYY-MM-DD
      category,
      supplier: supplierFinal,
      amount: amountNum,
      quantity: qtyNum,
      total,
      description: description.trim(),
      createdAt: new Date().toISOString(),
    };

    console.log("EXPENSE:", payload);
    Alert.alert("Saved", "Your expense has been saved.", [
      { text: "OK", onPress: () => navigation.goBack() },
    ]);
  };

  const onPickDate = (_, selected) => {
    setShowDatePicker(false);
    if (selected) setDate(selected);
  };

  return (
    <SafeAreaView style={s.safe}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        keyboardVerticalOffset={Platform.OS === "ios" ? 12 : 0}
      >
        <ScrollView contentContainerStyle={s.container} keyboardShouldPersistTaps="handled">
          <Text style={s.title}>Add Expense</Text>

          {/* Date */}
          <Text style={s.label}>Date</Text>
          <TouchableOpacity style={s.dateBtn} onPress={() => setShowDatePicker(true)}>
            <Text style={s.dateText}>{formatDate(date)}</Text>
          </TouchableOpacity>
          {showDatePicker && (
            <DateTimePicker
              mode="date"
              value={date}
              onChange={onPickDate}
              display={Platform.OS === "ios" ? "inline" : "default"}
            />
          )}

          {/* Category */}
          <Text style={s.label}>Category</Text>
          <View style={s.chipsWrap}>
            {CATEGORIES.map((c) => {
              const active = c === category;
              return (
                <TouchableOpacity key={c} onPress={() => setCategory(c)} style={[s.chip, active && s.chipActive]}>
                  <Text style={[s.chipText, active && s.chipTextActive]}>{c}</Text>
                </TouchableOpacity>
              );
            })}
          </View>

          {/* Supplier */}
          <Text style={s.label}>Supplier</Text>
          <View style={s.chipsWrap}>
            {SUPPLIERS.map((sName) => {
              const active = sName === supplier;
              return (
                <TouchableOpacity key={sName} onPress={() => setSupplier(sName)} style={[s.chip, active && s.chipActive]}>
                  <Text style={[s.chipText, active && s.chipTextActive]}>{sName}</Text>
                </TouchableOpacity>
              );
            })}
          </View>
          {supplier === "Other" && (
            <TextInput
              value={newSupplier}
              onChangeText={setNewSupplier}
              placeholder="Enter supplier name"
              style={[s.input, { marginTop: 8 }]}
            />
          )}

          {/* Amount */}
          <Text style={s.label}>Amount (per unit)</Text>
          <TextInput
            value={amount}
            onChangeText={setAmount}
            placeholder="e.g. 49.99"
            keyboardType="decimal-pad"
            returnKeyType="next"
            style={s.input}
          />

          {/* Quantity */}
          <Text style={s.label}>Quantity</Text>
          <TextInput
            value={quantity}
            onChangeText={setQuantity}
            placeholder="e.g. 1"
            keyboardType="decimal-pad"
            style={s.input}
          />

          {/* Description */}
          <Text style={s.label}>Description (optional)</Text>
          <TextInput
            value={description}
            onChangeText={setDescription}
            placeholder="Short note"
            multiline
            style={[s.input, s.inputMultiline]}
          />

          {/* Summary */}
          <View style={s.summary}>
            <Text style={s.summaryTextLabel}>Total</Text>
            <Text style={s.summaryTextValue}>{isNaN(total) ? "-" : total.toFixed(2)} PLN</Text>
          </View>

          {/* Actions */}
          <TouchableOpacity
            style={[s.saveBtn, !canSave && { opacity: 0.5 }]}
            disabled={!canSave}
            onPress={onSave}
          >
            <Text style={s.saveBtnText}>Save Expense</Text>
          </TouchableOpacity>

          <TouchableOpacity style={s.cancelBtn} onPress={() => navigation.goBack()}>
            <Text style={s.cancelBtnText}>Cancel</Text>
          </TouchableOpacity>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

// helpers
const formatDate = (d) => {
  const y = d.getFullYear();
  const m = `${d.getMonth() + 1}`.padStart(2, "0");
  const day = `${d.getDate()}`.padStart(2, "0");
  return `${y}-${m}-${day}`;
};

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#FAFAFA" },
  container: { padding: 16, paddingBottom: 32 },
  title: { fontSize: 22, fontWeight: "700", color: "#0E1220", marginBottom: 12 },
  label: { fontSize: 13, color: "#6B7280", marginTop: 14, marginBottom: 6 },

  chipsWrap: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  chip: {
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 999,
    backgroundColor: "#F1F5F9",
  },
  chipActive: { backgroundColor: "#E8F7EF", borderWidth: 1, borderColor: "#1BAE70" },
  chipText: { color: "#334155", fontSize: 13, fontWeight: "600" },
  chipTextActive: { color: "#0F5132" },

  dateBtn: {
    backgroundColor: "white",
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 14,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.08)",
  },
  dateText: { fontSize: 15, color: "#0E1220", fontWeight: "600" },

  input: {
    backgroundColor: "white",
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 15,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.08)",
  },
  inputMultiline: { minHeight: 90, textAlignVertical: "top" },

  summary: {
    marginTop: 18,
    backgroundColor: "white",
    padding: 14,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.06)",
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  summaryTextLabel: { fontSize: 14, color: "#6B7280" },
  summaryTextValue: { fontSize: 18, fontWeight: "800", color: "#0E1220" },

  saveBtn: {
    marginTop: 20,
    backgroundColor: "#1BAE70",
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 14,
  },
  saveBtnText: { color: "white", fontWeight: "700", fontSize: 16 },

  cancelBtn: {
    marginTop: 10,
    backgroundColor: "#F3F4F6",
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 12,
  },
  cancelBtnText: { color: "#374151", fontWeight: "700" },
});
