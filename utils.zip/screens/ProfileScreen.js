// screens/ProfileScreen.js
import React from "react";
import { View, Text, SafeAreaView, StyleSheet } from "react-native";
import { COLORS } from "../utils/theme";

export default function ProfileScreen() {
  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.wrap}>
        <Text style={styles.h1}>Profile</Text>
        <Text style={styles.sub}>User profile / settings here.</Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.bg },
  wrap: { flex: 1, backgroundColor: COLORS.bg, alignItems: "center", justifyContent: "center", padding: 16 },
  h1: { fontSize: 24, fontWeight: "800", color: COLORS.text },
  sub: { marginTop: 8, color: COLORS.subtext },
});
