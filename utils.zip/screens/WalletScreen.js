// screens/ReportScreen.js
import React, { useEffect, useMemo, useState } from "react";
import {
  View,
  Text,
  SafeAreaView,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
} from "react-native";
import { COLORS } from "../utils/theme";
import Ionicons from "react-native-vector-icons/Ionicons";

import {
  getLastNDays,
  subscribeReportByDate,
  ymd,
} from "../services/reportService";

const WEEKDAY = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
const fmt = (n) =>
  typeof n === "number" && !Number.isNaN(n) ? `${n.toFixed(2)} PLN` : "-";
const prettyDate = (d) =>
  d.toLocaleDateString(undefined, { day: "numeric", month: "long" });

export default function ReportScreen() {
  const [baseDate] = useState(() => new Date());
  const todayId = useMemo(() => ymd(baseDate), [baseDate]);

  const [selected, setSelected] = useState(todayId);
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);

  const days = useMemo(() => {
    const arr = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(baseDate);
      d.setDate(baseDate.getDate() - i);
      arr.push(d);
    }
    return arr;
  }, [baseDate]);

  const dataMap = useMemo(
    () => Object.fromEntries(reports.map((r) => [r.date, r])),
    [reports]
  );

  useEffect(() => {
    (async () => {
      setLoading(true);
      try {
        const res = await getLastNDays(7, baseDate);
        setReports(res);
      } finally {
        setLoading(false);
      }
    })();
  }, [baseDate]);

  useEffect(() => {
    const unsub = subscribeReportByDate(todayId, (doc) => {
      if (!doc) return;
      setReports((prev) => {
        const without = prev.filter((p) => p.date !== doc.date);
        return [...without, doc].sort((a, b) => a.date.localeCompare(b.date));
      });
    });
    return unsub;
  }, [todayId]);

  const data = dataMap[selected];

  const totalRevenue = data?.totalRevenue ?? 0;
  const ordersTotal = data?.orders ?? 0; // <- mapped in reportService
  const channels = data?.channels ?? {};
  const ordersBy = data?.ordersByChannel ?? {
    inShop: 0, pyszne: 0, wolt: 0, uber: 0, glovo: 0, lungo: 0,
  };
  const cashInRegister = data?.cashInRegister ?? 0;
  const inventory = data?._raw?.inventory ?? {};

  if (loading) {
    return (
      <SafeAreaView style={s.safe}>
        <View style={[s.container, { alignItems: "center", justifyContent: "center", flex: 1 }]}>
          <ActivityIndicator />
          <Text style={{ marginTop: 8, color: COLORS.subtext }}>Loading reports…</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={s.safe}>
      <ScrollView contentContainerStyle={s.container}>
        {/* Week strip */}
        <Text style={s.h1}>Daily Overview</Text>
        <View style={s.weekRow}>
          {days.map((d) => {
            const key = ymd(d);
            const isSel = key === selected;
            const isToday = key === todayId;
            return (
              <TouchableOpacity
                key={key}
                onPress={() => setSelected(key)}
                activeOpacity={0.8}
                style={[s.day, isSel && s.dayActive]}
              >
                <Text style={[s.dayWeek, isSel && s.dayWeekActive]}>
                  {WEEKDAY[d.getDay()]}
                </Text>
                <Text style={[s.dayNum, isSel && s.dayNumActive]}>
                  {d.getDate()}
                </Text>
                {isToday && <Text style={s.todayDot}>•</Text>}
              </TouchableOpacity>
            );
          })}
        </View>

        {/* Selected day label */}
        <Text style={s.today}>TODAY: {prettyDate(new Date(selected))}</Text>

        {/* KPIs */}
        <View style={s.grid}>
          <View style={s.card}>
            <Text style={s.cardLabel}>Total revenue</Text>
            <Text style={s.cardValue}>{fmt(totalRevenue)}</Text>
          </View>
          <View style={s.card}>
            <Text style={s.cardLabel}>Total orders</Text>
            <Text style={s.cardValue}>{ordersTotal}</Text>
          </View>
        </View>

        {/* Channel breakdown: Amount + Orders pill */}
        <View style={s.block}>
          <Text style={s.blockTitle}>By channel</Text>

          <ChannelStatRow
            label="In shop"
            amount={channels.inShop}
            orders={ordersBy.inShop}
          />
          <ChannelStatRow
            label="Pyszne"
            amount={channels.pyszne}
            orders={ordersBy.pyszne}
          />
          <ChannelStatRow
            label="Wolt"
            amount={channels.wolt}
            orders={ordersBy.wolt}
          />
          <ChannelStatRow
            label="Uber"
            amount={channels.uber}
            orders={ordersBy.uber}
          />
          <ChannelStatRow
            label="Glovo"
            amount={channels.glovo}
            orders={ordersBy.glovo}
          />
          <ChannelStatRow
            label="LunGO"
            amount={channels.lungo}
            orders={ordersBy.lungo}
          />
        </View>

        {/* Cash */}
        <View style={s.cardWide}>
          <Text style={s.cardLabel}>Cash in register</Text>
          <Text style={s.cardValue}>{fmt(cashInRegister)}</Text>
        </View>

        {/* Daily checks */}
        <View style={s.block}>
          <Text style={s.blockTitle}>Daily checks</Text>
          <IconRow icon="pizza-outline" label="Pizza doughs" value={inventory.pizzaDoughs ?? 0} />
          <IconRow icon="cube-outline" label="Box 30cm" value={inventory.pizzaBox30cm ?? 0} />
          <IconRow icon="cube-outline" label="Box 40cm" value={inventory.pizzaBox40cm ?? 0} />
          <IconRow icon="fast-food-outline" label="Burger meat" value={inventory.burgerMeat ?? 0} />
        </View>

        <Text style={s.readonlyNote}>Read-only summary • Live from Firestore</Text>
      </ScrollView>
    </SafeAreaView>
  );
}

/** Channel row that shows Amount and an Orders pill with an icon */
function ChannelStatRow({ label, amount = 0, orders = 0 }) {
  return (
    <View style={s.row}>
      <Text style={s.rowLabel}>{label}</Text>
      <View style={{ flexDirection: "row", alignItems: "center", gap: 8 }}>
        <Text style={s.rowValue}>{fmt(amount)}</Text>
        <View style={s.ordersPill}>
          <Ionicons name="receipt-outline" size={14} color="#0F5132" />
          <Text style={s.ordersPillText}>{orders}</Text>
        </View>
      </View>
    </View>
  );
}

function IconRow({ icon, label, value }) {
  return (
    <View style={s.row}>
      <View style={{ flexDirection: "row", alignItems: "center", gap: 6 }}>
        <Ionicons name={icon} size={18} color={COLORS.text} />
        <Text style={s.rowLabel}>{label}</Text>
      </View>
      <Text style={s.rowValue}>{value}</Text>
    </View>
  );
}

const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.bg },
  container: { padding: 16, paddingBottom: 28, gap: 14 },
  h1: { fontSize: 22, fontWeight: "800", color: COLORS.text },

  weekRow: { flexDirection: "row", justifyContent: "space-between", gap: 6 },
  day: {
    flex: 1,
    backgroundColor: "#F1F5F9",
    borderRadius: 12,
    paddingVertical: 10,
    alignItems: "center",
    gap: 2,
  },
  dayActive: { backgroundColor: "#E8F7EF", borderWidth: 1, borderColor: "#1BAE70" },
  dayWeek: { fontSize: 11, color: COLORS.subtext, fontWeight: "600" },
  dayWeekActive: { color: "#126B46" },
  dayNum: { fontSize: 16, color: COLORS.text, fontWeight: "800" },
  dayNumActive: { color: "#0F5132" },
  todayDot: { color: "#1BAE70", marginTop: -4 },

  today: { marginTop: 2, color: COLORS.subtext, fontWeight: "700" },

  grid: { flexDirection: "row", gap: 12 },
  card: {
    flex: 1,
    backgroundColor: "white",
    borderRadius: 14,
    padding: 16,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.06)",
    justifyContent: "center",
    gap: 6,
  },
  cardWide: {
    backgroundColor: "white",
    borderRadius: 14,
    padding: 16,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.06)",
    justifyContent: "center",
    gap: 6,
  },
  cardLabel: { color: COLORS.subtext, fontSize: 12, fontWeight: "700" },
  cardValue: { color: COLORS.text, fontSize: 22, fontWeight: "800" },

  block: {
    backgroundColor: "white",
    borderRadius: 14,
    padding: 10,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.06)",
  },
  blockTitle: { fontSize: 14, fontWeight: "800", color: COLORS.text, marginBottom: 6 },

  row: {
    paddingVertical: 10,
    flexDirection: "row",
    justifyContent: "space-between",
    borderBottomWidth: 1,
    borderBottomColor: "rgba(0,0,0,0.06)",
  },
  rowLabel: { color: COLORS.text, fontWeight: "600" },
  rowValue: { color: COLORS.text, fontWeight: "800" },

  ordersPill: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 999,
    backgroundColor: "#E8F7EF",
    borderWidth: 1,
    borderColor: "rgba(27,174,112,0.4)",
  },
  ordersPillText: { color: "#0F5132", fontWeight: "800", fontSize: 12 },

  readonlyNote: { textAlign: "center", color: COLORS.subtext, fontSize: 12, marginTop: 4 },
});
