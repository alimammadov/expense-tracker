import React, { useEffect, useMemo, useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  SafeAreaView,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Alert,
} from "react-native";
import { COLORS } from "../utils/theme";

import { db } from "../firebase";
import { doc, setDoc, serverTimestamp, onSnapshot } from "firebase/firestore";

export default function TransferScreen({ navigation }) {
  // Keep a base date that we can update at midnight
  const [baseDate, setBaseDate] = useState(() => new Date());
  const dateId = useMemo(() => {
    const y = baseDate.getFullYear();
    const m = String(baseDate.getMonth() + 1).padStart(2, "0");
    const d = String(baseDate.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
  }, [baseDate]);

  const datePretty = useMemo(
    () =>
      baseDate.toLocaleDateString(undefined, {
        day: "numeric",
        month: "long",
        year: "numeric",
      }),
    [baseDate]
  );

  // Lock state: true means today's report already exists
  const [submitted, setSubmitted] = useState(false);

  // Revenue by channel (PLN)
  const [inShop, setInShop] = useState("");
  const [pyszne, setPyszne] = useState("");
  const [wolt, setWolt] = useState("");
  const [uber, setUber] = useState("");
  const [glovo, setGlovo] = useState("");
  const [lungo, setLungo] = useState("");

  // Orders by channel (pcs)
  const [inShopOrders, setInShopOrders] = useState("");
  const [pyszneOrders, setPyszneOrders] = useState("");
  const [woltOrders, setWoltOrders] = useState("");
  const [uberOrders, setUberOrders] = useState("");
  const [glovoOrders, setGlovoOrders] = useState("");
  const [lungoOrders, setLungoOrders] = useState("");

  // Daily checking
  const [cashToday, setCashToday] = useState("");

  // Inventory snapshot (counts)
  const [doughsCount, setDoughsCount] = useState("");
  const [box30, setBox30] = useState("");
  const [box40, setBox40] = useState("");
  const [burgerMeat, setBurgerMeat] = useState("");

  const num = (v) => {
    const n = parseFloat((v || "").toString().replace(",", "."));
    return Number.isFinite(n) && n >= 0 ? n : 0;
  };
  const int = (v) => {
    const n = parseInt((v || "").toString().trim(), 10);
    return Number.isFinite(n) && n >= 0 ? n : 0;
  };

  const totalRevenue = useMemo(
    () =>
      +(
        num(inShop) +
        num(pyszne) +
        num(wolt) +
        num(uber) +
        num(glovo) +
        num(lungo)
      ).toFixed(2),
    [inShop, pyszne, wolt, uber, glovo, lungo]
  );

  const totalOrders = useMemo(
    () =>
      int(inShopOrders) +
      int(pyszneOrders) +
      int(woltOrders) +
      int(uberOrders) +
      int(glovoOrders) +
      int(lungoOrders),
    [inShopOrders, pyszneOrders, woltOrders, uberOrders, glovoOrders, lungoOrders]
  );

  const canSave =
    !submitted &&
    [inShop, pyszne, wolt, uber, glovo, lungo].some((v) => v !== "") &&
    cashToday !== "" &&
    [doughsCount, box30, box40, burgerMeat].every((v) => v !== "");

  const buildPayload = () => ({
    date: dateId, // YYYY-MM-DD
    revenue: {
      byChannel: {
        inShop: num(inShop),
        pyszne: num(pyszne),
        wolt: num(wolt),
        uber: num(uber),
        glovo: num(glovo),
        lungo: num(lungo),
      },
      ordersByChannel: {
        inShop: int(inShopOrders),
        pyszne: int(pyszneOrders),
        wolt: int(woltOrders),
        uber: int(uberOrders),
        glovo: int(glovoOrders),
        lungo: int(lungoOrders),
      },
      ordersTotal: int(totalOrders),
      total: totalRevenue,
    },
    cash: { today: num(cashToday) },
    inventory: {
      pizzaDoughs: int(doughsCount),
      pizzaBox30cm: int(box30),
      pizzaBox40cm: int(box40),
      burgerMeat: int(burgerMeat),
    },
    createdAt: serverTimestamp(),
  });

  const onSavePressed = () => {
    if (!canSave) {
      Alert.alert(
        "Missing info",
        "Fill channel revenues, today's cash, and all inventory counts."
      );
      return;
    }

    Alert.alert("Confirm", "Are you sure you want to save today's daily report?", [
      { text: "Cancel", style: "cancel" },
      { text: "Yes, save", style: "destructive", onPress: saveToFirestore },
    ]);
  };

  const saveToFirestore = async () => {
    try {
      const payload = buildPayload();
      await setDoc(doc(db, "lungo_dailyRaport", dateId), payload, { merge: false });
      // Lock immediately after successful save
      setSubmitted(true);
      Alert.alert("Saved", "You submitted today's report. The form is locked until 00:00.", [
        { text: "Go to Reports", onPress: () => navigation.navigate("Wallet") },
        { text: "OK" },
      ]);
    } catch (e) {
      console.error("Save error:", e);
      Alert.alert("Error", "Could not save the daily report. Please try again.");
    }
  };

  // --- Live lock: subscribe to today's doc, lock if it exists ---
  useEffect(() => {
    const ref = doc(db, "lungo_dailyRaport", dateId);
    const unsub = onSnapshot(ref, (snap) => setSubmitted(snap.exists()));
    return unsub;
  }, [dateId]);

  // --- Auto-unlock at midnight: update baseDate to new day & clear form ---
  useEffect(() => {
    const now = new Date();
    const next = new Date(now);
    next.setDate(now.getDate() + 1);
    next.setHours(0, 0, 0, 0);
    const delay = next - now;

    const t = setTimeout(() => {
      // New day -> reset baseDate, clear fields, unlock
      setBaseDate(new Date());
      setSubmitted(false);
      clearForm();
    }, delay);

    return () => clearTimeout(t);
  }, [dateId]);

  const clearForm = () => {
    setInShop(""); setPyszne(""); setWolt(""); setUber(""); setGlovo(""); setLungo("");
    setInShopOrders(""); setPyszneOrders(""); setWoltOrders(""); setUberOrders(""); setGlovoOrders(""); setLungoOrders("");
    setCashToday("");
    setDoughsCount(""); setBox30(""); setBox40(""); setBurgerMeat("");
  };

  // If submitted, show the locked view
  if (submitted) {
    return (
      <SafeAreaView style={s.safe}>
        <View style={[s.container, { gap: 16 }]}>
          <Text style={s.h1}>Daily Report</Text>

          <View style={s.card}>
            <Text style={s.cardLabel}>TODAY</Text>
            <Text style={s.cardValue}>{datePretty}</Text>
          </View>

          <View style={s.lockCard}>
            <Text style={s.lockTitle}>You already submitted today's report ✅</Text>
            <Text style={s.lockText}>
              The form is locked until <Text style={{ fontWeight: "800" }}>00:00</Text>. Come back tomorrow or view your stats.
            </Text>

            <TouchableOpacity
              style={s.reportsBtn}
              onPress={() => navigation.navigate("Wallet")}
              accessibilityRole="button"
              accessibilityLabel="Go to reports"
            >
              <Text style={s.reportsBtnText}>Go to Reports</Text>
            </TouchableOpacity>
          </View>
        </View>
      </SafeAreaView>
    );
  }

  // Otherwise show the entry form
  return (
    <SafeAreaView style={s.safe}>
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        keyboardVerticalOffset={Platform.OS === "ios" ? 12 : 0}
      >
        <ScrollView contentContainerStyle={s.container} keyboardShouldPersistTaps="handled">
          <Text style={s.h1}>Daily Report</Text>

          {/* Date (read-only) */}
          <View style={s.card}>
            <Text style={s.cardLabel}>TODAY</Text>
            <Text style={s.cardValue}>{datePretty}</Text>
          </View>

          {/* Revenue by channel (amount + orders) */}
          <Text style={s.section}>Revenue by channel</Text>

          <ChannelRow label="In shop" amount={inShop} setAmount={setInShop} orders={inShopOrders} setOrders={setInShopOrders} />
          <ChannelRow label="Pyszne" amount={pyszne} setAmount={setPyszne} orders={pyszneOrders} setOrders={setPyszneOrders} />
          <ChannelRow label="Wolt" amount={wolt} setAmount={setWolt} orders={woltOrders} setOrders={setWoltOrders} />
          <ChannelRow label="Uber" amount={uber} setAmount={setUber} orders={uberOrders} setOrders={setUberOrders} />
          <ChannelRow label="Glovo" amount={glovo} setAmount={setGlovo} orders={glovoOrders} setOrders={setGlovoOrders} />
          <ChannelRow label="LunGO" amount={lungo} setAmount={setLungo} orders={lungoOrders} setOrders={setLungoOrders} />

          {/* Totals */}
          <View style={s.summary}>
            <View>
              <Text style={s.summaryLabel}>Total revenue</Text>
              <Text style={s.summaryValue}>{totalRevenue.toFixed(2)} PLN</Text>
            </View>
            <View style={{ alignItems: "flex-end" }}>
              <Text style={s.summaryLabel}>Total orders</Text>
              <Text style={s.summaryValue}>{totalOrders}</Text>
            </View>
          </View>

          {/* Today cash only */}
          <Text style={s.section}>Daily checking</Text>
          <View style={s.grid}>
            <Field
              containerStyle={s.half}
              label="Cash today (PLN)"
              value={cashToday}
              onChangeText={setCashToday}
              keyboardType="decimal-pad"
            />
          </View>

          {/* Inventory snapshot */}
          <Text style={s.section}>Inventory snapshot</Text>
          <View style={s.grid}>
            <Field containerStyle={s.half} label="Pizza doughs (pcs)" value={doughsCount} onChangeText={setDoughsCount} keyboardType="number-pad" />
            <Field containerStyle={s.half} label="Pizza box 30 cm (pcs)" value={box30} onChangeText={setBox30} keyboardType="number-pad" />
            <Field containerStyle={s.half} label="Pizza box 40 cm (pcs)" value={box40} onChangeText={setBox40} keyboardType="number-pad" />
            <Field containerStyle={s.half} label="Burger meat (pcs)" value={burgerMeat} onChangeText={setBurgerMeat} keyboardType="number-pad" />
          </View>

          {/* Actions */}
          <TouchableOpacity
            style={[s.saveBtn, !canSave && { opacity: 0.6 }]}
            disabled={!canSave}
            onPress={onSavePressed}
            accessibilityRole="button"
            accessibilityLabel="Save daily report"
          >
            <Text style={s.saveBtnText}>Save</Text>
          </TouchableOpacity>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

/** One labeled row with Amount + Orders side-by-side */
function ChannelRow({ label, amount, setAmount, orders, setOrders }) {
  return (
    <View style={s.channelRow}>
      <Text style={s.fieldLabel}>{label}</Text>
      <View style={s.inline}>
        <TextInput
          value={amount}
          onChangeText={setAmount}
          placeholder="Amount (PLN)"
          keyboardType="decimal-pad"
          style={[s.input, s.inputHalf]}
          placeholderTextColor="#6B7280"
        />
        <TextInput
          value={orders}
          onChangeText={setOrders}
          placeholder="Orders"
          keyboardType="number-pad"
          style={[s.input, s.inputHalf]}
          placeholderTextColor="#6B7280"
        />
      </View>
    </View>
  );
}

/** Generic half-width field */
function Field({ label, value, onChangeText, keyboardType = "decimal-pad", containerStyle }) {
  return (
    <View style={[s.field, containerStyle]}>
      <Text style={s.fieldLabel}>{label}</Text>
      <TextInput
        value={value}
        onChangeText={onChangeText}
        placeholder="0"
        keyboardType={keyboardType}
        style={s.input}
        placeholderTextColor="#6B7280"
      />
    </View>
  );
}

const s = StyleSheet.create({
  // Layout
  safe: { flex: 1, backgroundColor: COLORS.bg },
  container: { padding: 16, paddingBottom: 32, gap: 12 },
  h1: { fontSize: 24, fontWeight: "800", color: COLORS.text },

  section: { fontSize: 15, color: COLORS.text, fontWeight: "800", marginTop: 10, marginBottom: 4 },

  grid: { flexDirection: "row", flexWrap: "wrap", justifyContent: "space-between" },
  half: { width: "48%" },

  // Card
  card: { backgroundColor: "#FFFFFF", borderRadius: 14, padding: 16, borderWidth: 1, borderColor: "rgba(0,0,0,0.15)" },
  cardLabel: { color: "#374151", fontSize: 12, fontWeight: "800", letterSpacing: 0.2 },
  cardValue: { color: "#0E1220", fontSize: 18, fontWeight: "800", marginTop: 4 },

  // Locked state card
  lockCard: { backgroundColor: "#E8F7EF", borderRadius: 14, padding: 16, borderWidth: 1, borderColor: "rgba(27,174,112,0.35)", gap: 8 },
  lockTitle: { fontSize: 16, fontWeight: "900", color: "#0F5132" },
  lockText: { fontSize: 14, color: "#0F5132" },
  reportsBtn: { marginTop: 8, backgroundColor: "#12885A", paddingVertical: 14, borderRadius: 12, alignItems: "center" },
  reportsBtnText: { color: "#FFFFFF", fontWeight: "800", fontSize: 16 },

  // Field
  field: { marginTop: 8, marginBottom: 8 },
  channelRow: { marginTop: 8, marginBottom: 8 },
  fieldLabel: { fontSize: 13, color: "#374151", fontWeight: "700" },
  inline: { flexDirection: "row", gap: 8 },
  inputHalf: { flex: 1 },

  input: {
    marginTop: 6,
    backgroundColor: "#FFFFFF",
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 13,
    fontSize: 16,
    color: "#0E1220",
    borderWidth: 1.2,
    borderColor: "rgba(0,0,0,0.18)",
  },

  // Summary
  summary: {
    marginTop: 12,
    backgroundColor: "#FFFFFF",
    padding: 16,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: "rgba(0,0,0,0.15)",
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    gap: 12,
  },
  summaryLabel: { fontSize: 14, color: "#374151", fontWeight: "800" },
  summaryValue: { fontSize: 20, color: "#0E1220", fontWeight: "900" },

  // Actions
  saveBtn: {
    marginTop: 18,
    marginBottom:90,
    backgroundColor: "#12885A",
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 16,
  },
  saveBtnText: { color: "#FFFFFF", fontWeight: "800", fontSize: 16 },
});
