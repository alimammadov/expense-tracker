// screens/HomeScreen.js
import React, { useState } from "react";
import { View, Text, SafeAreaView, StyleSheet, TouchableOpacity, FlatList } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import Svg, { Circle } from "react-native-svg";
import { COLORS } from "../utils/theme";

const filters = ["All", "Daily", "Weekly"];

const tx = [
  { id: "1", title: "Food", method: "Card", amount: -12, date: "Mar 07, 2023", icon: "cafe", color: "#FFEFD3" },
  { id: "2", title: "Salary", method: "Bank Account", amount: 6800, date: "Mar 07, 2023", icon: "cash", color: "#E6F7F1" },
  { id: "3", title: "Entertainment", method: "Card", amount: -8, date: "Mar 07, 2023", icon: "film-outline", color: "#EFE8FF" },
];

function Donut({ income = 8429, spent = 3621, size = 160, stroke = 18 }) {
  const r = (size - stroke) / 2;
  const cx = size / 2, cy = size / 2;
  const total = Math.max(income + spent, 1);
  const inc = income / total, sp = spent / total;
  const C = 2 * Math.PI * r, gap = 10;

  return (
    <View style={{ width: size, height: size, alignItems: "center", justifyContent: "center" }}>
      <Svg width={size} height={size}>
        <Circle cx={cx} cy={cy} r={r} stroke="#F1F3F6" strokeWidth={stroke} fill="none" />
        <Circle cx={cx} cy={cy} r={r} stroke={COLORS.green} strokeWidth={stroke} strokeLinecap="round"
          strokeDasharray={`${inc * (C - gap)} ${C}`} rotation="-90" origin={`${cx}, ${cy}`} fill="none" />
        <Circle cx={cx} cy={cy} r={r} stroke={COLORS.red} strokeWidth={stroke} strokeLinecap="round"
          strokeDasharray={`${sp * (C - gap)} ${C}`} rotation={-90 + inc * 360} origin={`${cx}, ${cy}`} fill="none" />
      </Svg>
      <View style={{ position: "absolute", alignItems: "center" }}>
        <Text style={{ color: COLORS.subtext, fontSize: 12 }}>Balance</Text>
        <Text style={{ color: COLORS.text, fontSize: 20, fontWeight: "800" }}>
          ${(income - spent).toLocaleString()}
        </Text>
      </View>
    </View>
  );
}

export default function HomeScreen() {
  const [activeFilter, setActiveFilter] = useState("All");
  const income = 8429, spent = 3621;

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.screen}>
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.hello}>Hello,</Text>
            <Text style={styles.name}>David</Text>
          </View>
          <View style={styles.bell}>
            <Ionicons name="notifications-outline" size={20} color={COLORS.text} />
          </View>
        </View>

        {/* Filters */}
        <View style={styles.filters}>
          {filters.map((f) => (
            <TouchableOpacity key={f} onPress={() => setActiveFilter(f)}
              style={[styles.chip, activeFilter === f && styles.chipActive]}>
              <Text style={[styles.chipText, activeFilter === f && styles.chipTextActive]}>{f}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Donut card */}
        <View style={styles.card}>
          <View style={{ flex: 1, justifyContent: "center" }}>
            <View style={styles.legendRow}>
              <View style={[styles.dot, { backgroundColor: COLORS.green }]} />
              <Text style={styles.legendLabel}>Income</Text>
            </View>
            <Text style={[styles.value, { color: COLORS.text }]}>${income.toLocaleString()}</Text>

            <View style={{ height: 12 }} />

            <View style={styles.legendRow}>
              <View style={[styles.dot, { backgroundColor: COLORS.red }]} />
              <Text style={styles.legendLabel}>Spent</Text>
            </View>
            <Text style={[styles.value, { color: COLORS.text }]}>${spent.toLocaleString()}</Text>
          </View>
          <Donut income={income} spent={spent} />
        </View>

        {/* Recent */}
        <View style={styles.rowBetween}>
          <Text style={styles.sectionTitle}>Recent transactions</Text>
          <TouchableOpacity style={styles.seeAllBtn}>
            <Text style={styles.seeAllText}>See All</Text>
          </TouchableOpacity>
        </View>

        <FlatList
          data={tx}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ paddingBottom: 110 }}
          renderItem={({ item }) => (
            <View style={styles.txRow}>
              <View style={[styles.txIconWrap, { backgroundColor: item.color }]}>
                {item.icon === "cafe" && <Ionicons name="cafe" size={22} color={COLORS.text} />}
                {item.icon === "cash" && <Ionicons name="cash" size={22} color={COLORS.text} />}
                {item.icon === "film-outline" && <Ionicons name="film-outline" size={22} color={COLORS.text} />}
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.txTitle}>{item.title}</Text>
                <Text style={styles.txSub}>{item.method}  •  {item.date}</Text>
              </View>
              <Text style={[styles.amount, { color: item.amount >= 0 ? COLORS.green : COLORS.text }]}>
                {item.amount >= 0 ? `$${item.amount}` : `-$${Math.abs(item.amount)}`}
              </Text>
            </View>
          )}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.bg },
  screen: { flex: 1, paddingHorizontal: 18, paddingTop: 14, backgroundColor: COLORS.bg },

  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 10 },
  hello: { color: COLORS.subtext, fontSize: 16 },
  name: { color: COLORS.text, fontSize: 28, fontWeight: "800" },
  bell: { width: 38, height: 38, borderRadius: 12, backgroundColor: COLORS.card, alignItems: "center", justifyContent: "center" },

  filters: { flexDirection: "row", gap: 10, marginVertical: 8 },
  chip: { paddingHorizontal: 14, paddingVertical: 8, backgroundColor: COLORS.chip, borderRadius: 16 },
  chipActive: { backgroundColor: COLORS.greenSoft },
  chipText: { color: COLORS.text, fontWeight: "600" },
  chipTextActive: { color: COLORS.green },

  card: { marginTop: 10, backgroundColor: COLORS.card, borderRadius: 16, padding: 16, flexDirection: "row", alignItems: "center", gap: 10 },
  legendRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  legendLabel: { color: COLORS.subtext },
  value: { fontSize: 20, fontWeight: "800", marginTop: 2 },
  dot: { width: 10, height: 10, borderRadius: 5 },

  rowBetween: { marginTop: 18, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  sectionTitle: { fontSize: 16, fontWeight: "800", color: COLORS.text },
  seeAllBtn: { paddingHorizontal: 12, paddingVertical: 6, backgroundColor: COLORS.card, borderRadius: 14 },
  seeAllText: { color: COLORS.subtext, fontWeight: "600" },

  txRow: { flexDirection: "row", alignItems: "center", gap: 12, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  txIconWrap: { width: 44, height: 44, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  txTitle: { fontSize: 15, fontWeight: "700", color: COLORS.text },
  txSub: { color: COLORS.subtext, marginTop: 2 },
  amount: { fontWeight: "800", fontSize: 15 },
});
