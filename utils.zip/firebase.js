// firebase.js
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyAbzrJ-AQAiiBrVoEQCbFXIZqZFJWnrTeg",
  authDomain: "stocktracker-f6da3.firebaseapp.com",
  projectId: "stocktracker-f6da3",
  storageBucket: "stocktracker-f6da3.appspot.com", // 👈 double-check spelling
  messagingSenderId: "666687284343",
  appId: "1:666687284343:web:6d6dd34f40ee7d79fa5272",
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
