// theme.js
export  const COLORS = {
  bg: "#FFFFFF",
  text: "#0E1220",
  subtext: "#7D8592",
  card: "#F6F7FB",
  green: "#1BAE70",
  greenSoft: "#E8F7EF",
  red: "#F7A9A4",
  chip: "#EEF1F6",
  border: "#E8EAF0",
  tab: "#FFFFFF",
};
