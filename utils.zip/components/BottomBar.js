// components/BottomBar.js
import React from "react";
import { View, Text, TouchableOpacity, StyleSheet, Platform } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons, MaterialCommunityIcons, Feather } from "@expo/vector-icons";

export default function BottomBar({ state, navigation, colors = {
  tab: "#FFFFFF",
  bg: "#FFFFFF",
  green: "#1BAE70",
  greenSoft: "#E8F7EF",
  subtext: "#7D8592",
} }) {
  const s = makeStyles(colors);
  const insets = useSafeAreaInsets();

  const isFocused = (name) => {
    const idx = state.routes.findIndex(r => r.name === name);
    return state.index === idx;
  };

  const pressTab = (name) => {
    const idx = state.routes.findIndex(r => r.name === name);
    const route = state.routes[idx];
    if (!route) return;

    const event = navigation.emit({
      type: "tabPress",
      target: route.key,          // use key for tabPress
      canPreventDefault: true,
    });

    if (!event.defaultPrevented) navigation.navigate(route.name);
  };

  const longPressTab = (name) => {
    const idx = state.routes.findIndex(r => r.name === name);
    const route = state.routes[idx];
    if (!route) return;

    navigation.emit({ type: "tabLongPress", target: route.key });
  };

  return (
    <View style={[s.tabbar, { paddingBottom: Math.max(insets.bottom, 12) }]}>
      {/* Concave notch */}
      <View style={s.notch} />

      {/* Home */}
      <TouchableOpacity
        accessibilityRole="button"
        accessibilityState={isFocused("Home") ? { selected: true } : {}}
        accessibilityLabel="Home"
        onPress={() => pressTab("Home")}
        onLongPress={() => longPressTab("Home")}
        style={[s.tabItem, isFocused("Home") && s.tabItemActive]}
      >
        <Feather name="home" size={22} color={isFocused("Home") ? colors.green : colors.subtext} />
        <Text style={[s.tabLabel, isFocused("Home") && s.tabLabelActive]}>Home</Text>
      </TouchableOpacity>

      {/* Transfer */}

      <TouchableOpacity
        accessibilityRole="button"
        accessibilityState={isFocused("Transfer") ? { selected: true } : {}}
        accessibilityLabel="Transfer"
        onPress={() => pressTab("Transfer")}
        onLongPress={() => longPressTab("Transfer")}
        style={[s.tabItem, isFocused("Transfer") && s.tabItemActive]}
      >
        <Feather name="check-square" size={22} color={isFocused("Transfer") ? colors.green : colors.subtext} />
        <Text style={[s.tabLabel, isFocused("Transfer") && s.tabLabelActive]}>Report</Text>
      </TouchableOpacity>

      {/* Center FAB -> AddExpense */}
      <TouchableOpacity
        style={s.fab}
        onPress={() => pressTab("AddExpense")}
        accessibilityRole="button"
        accessibilityLabel="Add expense"
      >
        <Ionicons name="add" size={26} color="#0E1220" />
      </TouchableOpacity>

      {/* Wallet */}
      <TouchableOpacity
        accessibilityRole="button"
        accessibilityState={isFocused("Wallet") ? { selected: true } : {}}
        accessibilityLabel="Wallet"
        onPress={() => pressTab("Wallet")}
        onLongPress={() => longPressTab("Wallet")}
        style={[s.tabItem, isFocused("Wallet") && s.tabItemActive]}
      >
        <MaterialCommunityIcons
          name="chart-timeline-variant"
          size={22}
          color={isFocused("Wallet") ? colors.green : colors.subtext}
        />
        <Text style={[s.tabLabel, isFocused("Wallet") && s.tabLabelActive]}>Stat</Text>
      </TouchableOpacity>

      {/* Profile */}
      <TouchableOpacity
        accessibilityRole="button"
        accessibilityState={isFocused("Profile") ? { selected: true } : {}}
        accessibilityLabel="Profile"
        onPress={() => pressTab("Profile")}
        onLongPress={() => longPressTab("Profile")}
        style={[s.tabItem, isFocused("Profile") && s.tabItemActive]}
      >
        <Feather name="user" size={22} color={isFocused("Profile") ? colors.green : colors.subtext} />
        <Text style={[s.tabLabel, isFocused("Profile") && s.tabLabelActive]}>Profile</Text>
      </TouchableOpacity>
    </View>
  );
}

const makeStyles = (COLORS) =>
  StyleSheet.create({
    tabbar: {
      position: "absolute",
      left: 0,
      right: 0,
      bottom: -1,
      height: 84,
      backgroundColor: COLORS.tab,
      borderTopLeftRadius: 20,
      borderTopRightRadius: 20,
      flexDirection: "row",
      alignItems: "flex-end",
      justifyContent: "space-around",
      // paddingBottom set dynamically with safe area
      borderTopWidth: Platform.OS === "android" ? 1 : 0,
      borderTopColor: Platform.OS === "android" ? "rgba(0,0,0,0.08)" : "transparent",
      elevation: 0,
    },
    notch: {
      position: "absolute",
      top: -48,
      left: "50%",
      width: 80,
      height: 80,
      marginLeft: -40,
      borderRadius: 40,
      backgroundColor: COLORS.bg,
    },
    fab: {
      position: "absolute",
      top: -40,
      left: "50%",
      marginLeft: -28,
      width: 56,
      height: 56,
      borderRadius: 28,
      backgroundColor: "#CFE9D8",
      alignItems: "center",
      justifyContent: "center",
      shadowColor: "#000",
      shadowOpacity: 0.1,
      shadowRadius: 8,
      shadowOffset: { width: 0, height: 4 },
      elevation: 6,
    },
    tabItem: {
      alignItems: "center",
      justifyContent: "center",
      flex: 1,
      paddingVertical: 6,
      gap: 4,
    },
    tabItemActive: {},
    tabLabel: { fontSize: 11, color: COLORS.subtext, fontWeight: "600" },
    tabLabelActive: { color: COLORS.green, fontWeight: "700" },
  });
