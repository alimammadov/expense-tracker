// App.js
import React, { useState } from "react";
import { View, Text, SafeAreaView, StyleSheet, TouchableOpacity, FlatList, Image, Platform } from "react-native";
import { Ionicons, MaterialCommunityIcons, Feather } from "@expo/vector-icons";
import Svg, { Circle } from "react-native-svg";

const COLORS = {
  bg: "#F6F7FB",
  text: "#0E1220",
  subtext: "#7D8592",
  card: "#FFFFFF",
  green: "#7ED9A6",
  red: "#F7A9A4",
  chip: "#EEF1F6",
  chipActive: "#E8F7EF",
  border: "#E8EAF0",
};

const filters = ["All", "Daily", "Weekly"];

const tx = [
  { id: "1", title: "Food", method: "Card", amount: -12, date: "Mar 07, 2023", icon: "cafe", color: "#FFEFD3" },
  { id: "2", title: "Salary", method: "Bank Account", amount: 6800, date: "Mar 07, 2023", icon: "cash", color: "#E6F7F1" },
  { id: "3", title: "Entertainment", method: "Card", amount: -8, date: "Mar 07, 2023", icon: "film-outline", color: "#EFE8FF" },
];

function Donut({ income = 8429, spent = 3621, size = 160, stroke = 18 }) {
  const radius = (size - stroke) / 2;
  const cx = size / 2;
  const cy = size / 2;
  const total = Math.max(income + spent, 1);
  const incPct = income / total;
  const spPct = spent / total;
  const C = 2 * Math.PI * radius;

  // little gap between segments
  const gap = 10;

  return (
    <View style={{ width: size, height: size, alignItems: "center", justifyContent: "center" }}>
      <Svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        {/* background circle */}
        <Circle cx={cx} cy={cy} r={radius} stroke="#F1F3F6" strokeWidth={stroke} fill="none" />
        {/* income arc */}
        <Circle
          cx={cx}
          cy={cy}
          r={radius}
          stroke={COLORS.green}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={`${incPct * (C - gap)} ${C}`}
          rotation="-90"
          origin={`${cx}, ${cy}`}
          fill="none"
        />
        {/* spent arc sits after income */}
        <Circle
          cx={cx}
          cy={cy}
          r={radius}
          stroke={COLORS.red}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={`${spPct * (C - gap)} ${C}`}
          rotation={-90 + (incPct * 360)}
          origin={`${cx}, ${cy}`}
          fill="none"
        />
      </Svg>

      <View style={{ position: "absolute", alignItems: "center" }}>
        <Text style={{ color: COLORS.subtext, fontSize: 12 }}>Balance</Text>
        <Text style={{ color: COLORS.text, fontSize: 20, fontWeight: "800" }}>
          ${(income - spent).toLocaleString()}
        </Text>
      </View>
    </View>
  );
}

export default function App() {
  const [active, setActive] = useState("All");
  const income = 8429;
  const spent = 3621;

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.screen}>
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.hello}>Hello,</Text>
            <Text style={styles.name}>David</Text>
          </View>
          <View style={styles.bell}>
            <Ionicons name="notifications-outline" size={20} color={COLORS.text} />
          </View>
        </View>

        {/* Filters */}
        <View style={styles.filters}>
          {filters.map((f) => (
            <TouchableOpacity key={f} onPress={() => setActive(f)} style={[styles.chip, active === f && styles.chipActive]}>
              <Text style={[styles.chipText, active === f && styles.chipTextActive]}>{f}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Donut Card */}
        <View style={styles.card}>
          <View style={{ flex: 1, justifyContent: "center" }}>
            <View style={styles.legendRow}>
              <View style={[styles.dot, { backgroundColor: COLORS.green }]} />
              <Text style={styles.legendLabel}>Income</Text>
            </View>
            <Text style={[styles.value, { color: COLORS.text }]}>${income.toLocaleString()}</Text>

            <View style={{ height: 12 }} />

            <View style={styles.legendRow}>
              <View style={[styles.dot, { backgroundColor: COLORS.red }]} />
              <Text style={styles.legendLabel}>Spent</Text>
            </View>
            <Text style={[styles.value, { color: COLORS.text }]}>${spent.toLocaleString()}</Text>
          </View>

          <Donut income={income} spent={spent} />
        </View>

        {/* Recent Transactions header */}
        <View style={styles.rowBetween}>
          <Text style={styles.sectionTitle}>Recent transactions</Text>
          <TouchableOpacity style={styles.seeAllBtn}>
            <Text style={styles.seeAllText}>See All</Text>
          </TouchableOpacity>
        </View>

        {/* Transactions list */}
        <FlatList
          data={tx}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ paddingBottom: 90 }}
          renderItem={({ item }) => (
            <View style={styles.txRow}>
              <View style={[styles.txIconWrap, { backgroundColor: item.color }]}>
                {item.icon === "cafe" && <Ionicons name="cafe" size={22} color={COLORS.text} />}
                {item.icon === "cash" && <Ionicons name="cash" size={22} color={COLORS.text} />}
                {item.icon === "film-outline" && <Ionicons name="film-outline" size={22} color={COLORS.text} />}
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.txTitle}>{item.title}</Text>
                <Text style={styles.txSub}>
                  {item.method}  •  {item.date}
                </Text>
              </View>
              <Text style={[styles.amount, { color: item.amount >= 0 ? COLORS.green : COLORS.text }]}>
                {item.amount >= 0 ? `$${item.amount}` : `-$${Math.abs(item.amount)}`}
              </Text>
            </View>
          )}
        />

        {/* Bottom bar (mock) */}
        <View style={styles.tabbar}>
          <View style={styles.tabItem}>
            <Feather name="home" size={22} color={COLORS.text} />
            <Text style={styles.tabLabel}>Home</Text>
          </View>
          <View style={styles.tabItem}>
            <Feather name="refresh-ccw" size={22} color={COLORS.subtext} />
            <Text style={[styles.tabLabel, { color: COLORS.subtext }]}>Transfer</Text>
          </View>

          <TouchableOpacity style={styles.fab}>
            <Ionicons name="add" size={26} color="white" />
          </TouchableOpacity>

          <View style={styles.tabItem}>
            <MaterialCommunityIcons name="wallet-outline" size={22} color={COLORS.subtext} />
            <Text style={[styles.tabLabel, { color: COLORS.subtext }]}>Wallet</Text>
          </View>
          <View style={styles.tabItem}>
            <Feather name="user" size={22} color={COLORS.subtext} />
            <Text style={[styles.tabLabel, { color: COLORS.subtext }]}>Profile</Text>
          </View>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.bg },
  screen: { flex: 1, paddingHorizontal: 18, paddingTop: 14 },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginBottom: 10 },
  hello: { color: COLORS.subtext, fontSize: 16 },
  name: { color: COLORS.text, fontSize: 28, fontWeight: "800" },
  bell: {
    width: 38, height: 38, borderRadius: 12, backgroundColor: COLORS.card,
    alignItems: "center", justifyContent: "center",
    shadowColor: "#000", shadowOpacity: 0.05, shadowRadius: 8, shadowOffset: { width: 0, height: 3 }, elevation: 2,
  },

  filters: { flexDirection: "row", gap: 10, marginVertical: 8 },
  chip: {
    paddingHorizontal: 14, paddingVertical: 8, backgroundColor: COLORS.chip, borderRadius: 16,
  },
  chipActive: { backgroundColor: COLORS.chipActive },
  chipText: { color: COLORS.text, fontWeight: "600" },
  chipTextActive: { color: "#1BAE70" },

  card: {
    marginTop: 10, backgroundColor: COLORS.card, borderRadius: 16, padding: 16, flexDirection: "row",
    alignItems: "center", gap: 10,
    shadowColor: "#000", shadowOpacity: 0.06, shadowRadius: 10, shadowOffset: { width: 0, height: 6 }, elevation: 3,
  },
  legendRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  legendLabel: { color: COLORS.subtext },
  value: { fontSize: 20, fontWeight: "800", marginTop: 2 },
  dot: { width: 10, height: 10, borderRadius: 5 },

  rowBetween: { marginTop: 18, flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  sectionTitle: { fontSize: 16, fontWeight: "800", color: COLORS.text },
  seeAllBtn: { paddingHorizontal: 12, paddingVertical: 6, backgroundColor: COLORS.card, borderRadius: 14 },
  seeAllText: { color: COLORS.subtext, fontWeight: "600" },

  txRow: {
    flexDirection: "row", alignItems: "center", gap: 12, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: COLORS.border,
  },
  txIconWrap: { width: 44, height: 44, borderRadius: 14, alignItems: "center", justifyContent: "center" },
  txTitle: { fontSize: 15, fontWeight: "700", color: COLORS.text },
  txSub: { color: COLORS.subtext, marginTop: 2 },
  amount: { fontWeight: "800", fontSize: 15 },

  tabbar: {
    position: "absolute", left: 18, right: 18, bottom: 18, height: 64, backgroundColor: COLORS.card,
    borderRadius: 22, flexDirection: "row", alignItems: "center", justifyContent: "space-around",
    shadowColor: "#000", shadowOpacity: 0.08, shadowRadius: 12, shadowOffset: { width: 0, height: 6 }, elevation: 6,
  },
  tabItem: { alignItems: "center", justifyContent: "center" },
  tabLabel: { marginTop: 4, fontSize: 11, color: COLORS.text, fontWeight: "600" },
  fab: {
    position: "absolute", left: "50%", transform: [{ translateX: -28 }], bottom: 18, width: 56, height: 56,
    borderRadius: 28, backgroundColor: "#60C593", alignItems: "center", justifyContent: "center",
    shadowColor: "#000", shadowOpacity: 0.1, shadowRadius: 10, shadowOffset: { width: 0, height: 6 }, elevation: 6,
  },
});
